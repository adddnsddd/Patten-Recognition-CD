# 扫地机器人二维仿真

课程设计演示程序，支持房间仿真、手动驾驶、自动清扫、避障、电量显示和日志导出。

## 运行

双击 [RobotCleaner.exe](../RobotCleaner.exe)，无需安装Python。项目内另有 [RobotCleaner-Portable.exe](dist/RobotCleaner-Portable.exe)，两者是相同版本。

源码运行需要Python3.9或更高版本及Tkinter，在本项目目录执行：

```powershell
python app.py
```

## 基本操作

1. 选择房间场景及清扫方式：弓字形覆盖、随机反弹或手动驾驶。
2. 设置初始电量和朝向，点击“重置”，再点击“开始运行”；支持暂停、单步和播放加速。
3. 手动模式下，点击地图后用方向键控制机器人。
4. 勾选雷达、栅格和规划路线查看图层；点击“导出日志”保存CSV。

弓字形条带走完后会针对遗漏区域规划补扫点。覆盖率达到95%后返站并显示任务完成；清扫阶段达到1200秒仍未达到95%，或遗漏区域无法规划路线时，显示任务失败并记录原因。随机模式达到95%后也会返站。

日志默认保存在EXE旁的 `outputs` 文件夹。切换场景或重置前，请先导出需要保留的数据。

## 主要文件

- `app.py`：界面与运行入口。
- `robot_sim/`：仿真模型、路径规划与控制。
- `outputs/`：运行日志。
- `tests/`：检查脚本。

当前已完成两种算法在两类场景的20种子对比、80%/40%/20%返航专项各20次、一次21%完整充电续扫验证和运动/空间/避障专项验证。复杂场景覆盖率与课程设计报告仍待完善。

## 多次实验

在项目目录运行 `python experiments/run_suite.py --runs 20 --workers 4`，会以相同种子序列、100%初始电量和0°初始朝向，分别对规则/复杂场景的覆盖方案与随机基线各运行20次。中断后重复命令会复用已有逐次结果。逐次JSON、事件JSON、完整逐步日志（gzip压缩CSV）及汇总表位于 `experiments/results/`。日志可用Python的 `gzip.open` 或支持gzip的解压软件查看。

对比图可用 `python experiments/make_charts.py` 重新生成；该脚本需要另装 `requirements-experiments.txt` 中的绘图库。实验方法、结果及限制见 [实验记录](experiments/results/report.md)。

返航实验用 `python experiments/run_return_suite.py --runs 20 --workers 4` 复现；`python experiments/check_21_closed_loop.py` 生成21%电量闭环曲线；`python experiments/validate_model.py` 生成运动、通道与行人避让专项结果。这三项图表脚本需要 `requirements-experiments.txt` 中的绘图库。全部逐步日志保存在对应的 `experiments/*_results/` 目录。
